package com.example.bsitfinalmobapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CropGuideActivity : AppCompatActivity() {

    private lateinit var provinceSpinner: Spinner
    private lateinit var guideTextView: TextView
    private lateinit var btnShowGuide: Button
    private lateinit var btnBackToMain: Button

    private val cropGuides = mapOf(
        "Nueva Ecija" to """
        🌾 **Rice**
        • Plant: June to July (start of rainy season)
        • Water: Keep soil flooded during early growth
        • Harvest: 100–120 days after sowing

        🌽 **Corn**
        • Plant: March to May
        • Water: Weekly deep watering
        • Harvest: When husks are dry and kernels hard

        🧅 **Onion**
        • Plant: October to December
        • Water: Twice a week, avoid waterlogging
        • Harvest: Tops fall and necks tighten
    """.trimIndent(),

        "Davao" to """
        🍌 **Banana**
        • Plant: Year-round with sufficient rainfall
        • Water: Every 2–3 days in dry season
        • Harvest: 9–12 months after planting

        🥥 **Coconut**
        • Plant: June to September
        • Water: Every 2 weeks (early stage)
        • Harvest: Every 45 days after 6 years

        🍫 **Cacao**
        • Plant: Start of rainy season
        • Water: Moderate; requires shade
        • Harvest: 5–6 months after flowering
    """.trimIndent(),

        "Benguet" to """
        🥬 **Lettuce**
        • Plant: Cold months (Oct–Feb)
        • Water: Daily light watering
        • Harvest: 30–40 days after planting

        🥕 **Carrot**
        • Plant: Sept–Feb (high altitude)
        • Water: 2–3 times per week
        • Harvest: 2–3 months after sowing

        🥬 **Cabbage**
        • Plant: October to March
        • Water: Regularly in dry months
        • Harvest: When heads are firm and full
    """.trimIndent(),

        "South Cotabato" to """
        🍍 **Pineapple**
        • Plant: During rainy season
        • Water: Every 3–4 days (young stage)
        • Harvest: 18–24 months after planting

        🌽 **Corn**
        • Plant: Start of dry season
        • Water: Weekly
        • Harvest: Kernels firm and husks brown

        🍌 **Banana**
        • Plant: Anytime with irrigation
        • Water: Consistently during dry season
        • Harvest: 10–12 months after planting
    """.trimIndent(),

        "Isabela" to """
        🌾 **Rice**
        • Plant: June or November
        • Water: Maintain 2–5 cm water
        • Harvest: 110 days after planting

        🌽 **Corn**
        • Plant: March to May
        • Water: 1 inch per week
        • Harvest: Husk turns brown

        🌱 **Mungbean**
        • Plant: After rice harvest
        • Water: Lightly every 4–5 days
        • Harvest: 60–75 days after sowing
    """.trimIndent(),

        "Iloilo" to """
        🌾 **Rice**
        • Plant: May to June
        • Water: Keep field moist
        • Harvest: 110 days after sowing

        🌽 **Corn**
        • Plant: February to April
        • Water: Weekly
        • Harvest: Kernel hard, husk dry

        🍬 **Sugarcane**
        • Plant: Wet season
        • Water: Only during dry months
        • Harvest: 10–18 months after planting
    """.trimIndent(),

        "Negros Occidental" to """
        🍬 **Sugarcane**
        • Plant: September to November
        • Water: Minimal, only during drought
        • Harvest: After 10–12 months

        🌾 **Rice**
        • Plant: May to July
        • Water: Flooded field
        • Harvest: After 100 days

        🍌 **Banana**
        • Plant: Year-round
        • Water: Regularly during dry season
        • Harvest: 10 months
    """.trimIndent(),

        "Camarines Sur" to """
        🥥 **Coconut**
        • Plant: May to October
        • Water: Moderate
        • Harvest: Every 45 days after 6 years

        🌾 **Rice**
        • Plant: June to July
        • Water: Maintain 3–5 cm
        • Harvest: 100–120 days

        🌿 **Abaca**
        • Plant: Rainy season
        • Water: Natural rainfall preferred
        • Harvest: 18–24 months
    """.trimIndent(),

        "Pangasinan" to """
        🍃 **Tobacco**
        • Plant: October to November
        • Water: Every 2 days initially
        • Harvest: 60–90 days after transplant

        🥭 **Mango**
        • Plant: Any time
        • Water: Weekly in dry season
        • Harvest: March to May

        🌾 **Rice**
        • Plant: May to June
        • Water: Flooded field
        • Harvest: 110–120 days
    """.trimIndent(),

        "Bukidnon" to """
        🍍 **Pineapple**
        • Plant: Rainy season
        • Water: 2x weekly when young
        • Harvest: 18 months

        🍬 **Sugarcane**
        • Plant: Start of wet season
        • Water: Minimal
        • Harvest: 10–18 months

        🍌 **Banana**
        • Plant: Year-round
        • Water: Every 2–3 days
        • Harvest: 9–12 months
    """.trimIndent()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop_guide)

        provinceSpinner = findViewById(R.id.spinnerCropProvince)
        guideTextView = findViewById(R.id.txtCropGuide)
        btnShowGuide = findViewById(R.id.btnShowGuide)
        btnBackToMain = findViewById(R.id.btnBackToMain)

        provinceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            cropGuides.keys.toList()
        )

        btnShowGuide.setOnClickListener {
            val selectedProvince = provinceSpinner.selectedItem.toString()
            val guide = cropGuides[selectedProvince] ?: "No guide available for selected province."
            guideTextView.text = guide
        }

        btnBackToMain.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}

package com.example.bsitfinalmobapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var infoText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Apply padding for system bars (status/nav bar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        infoText = findViewById(R.id.infoText)

        setupButtons()
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnWeather).setOnClickListener {
            startActivity(Intent(this, WeatherActivity::class.java))
        }

        findViewById<Button>(R.id.btnCropGuide).setOnClickListener {
            startActivity(Intent(this, CropGuideActivity::class.java))
        }

        findViewById<Button>(R.id.btnMarket).setOnClickListener {
            startActivity(Intent(this, MarketActivity::class.java))
        }

        findViewById<Button>(R.id.btnForum).setOnClickListener {
            infoText.text = "Farmer’s Forum: A community space where farmers can share experiences, ask questions, and get advice."
        }

        findViewById<Button>(R.id.btnAnalytics).setOnClickListener {
            infoText.text = "Farm Analytics: Visualizes data such as crop distribution and yield using a pie chart (to be implemented)."
        }
    }
}

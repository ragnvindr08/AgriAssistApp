package com.example.bsitfinalmobapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MarketActivity : AppCompatActivity() {

    // Data model
    data class CropPrice(
        val cropName: String,
        val priceUSD: Double,
        val pricePHP: Double,
        val exchange: String
    )

    private val apiKey = "DrwXdnGdHI1z5dD8+/a4uA==kgvyGZzI4GKZ7idE"
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CropAdapter
    private val cropList = mutableListOf<CropPrice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_market)

        // Back button setup
        findViewById<Button>(R.id.btnBackToMain).setOnClickListener { finish() }

        // RecyclerView setup
        recyclerView = findViewById(R.id.recyclerMarketPrices)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CropAdapter(cropList)
        recyclerView.adapter = adapter

        // Fetch commodity prices
        fetchPrices(listOf("rice", "corn", "wheat"))
    }

    private fun fetchPrices(commodities: List<String>) {
        CoroutineScope(Dispatchers.IO).launch {
            val fetched = mutableListOf<CropPrice>()

            for (name in commodities) {
                try {
                    val url = URL("https://api.api-ninjas.com/v1/commodityprice?name=$name")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.setRequestProperty("X-Api-Key", apiKey)
                    conn.requestMethod = "GET"
                    conn.connectTimeout = 5000
                    conn.readTimeout = 5000

                    if (conn.responseCode == 200) {
                        val response = conn.inputStream.bufferedReader().readText()
                        val jsonArray = JSONArray(response)

                        if (jsonArray.length() > 0) {
                            val obj = jsonArray.getJSONObject(0)
                            val usd = obj.getDouble("price")
                            val exchange = obj.optString("exchange", "N/A")
                            val php = usd * 56.0 // estimated PHP conversion
                            fetched.add(
                                CropPrice(
                                    cropName = name.replaceFirstChar { it.uppercaseChar() },
                                    priceUSD = usd,
                                    pricePHP = php,
                                    exchange = exchange
                                )
                            )
                        }
                    }
                    conn.disconnect()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            withContext(Dispatchers.Main) {
                cropList.clear()
                cropList.addAll(fetched)
                adapter.notifyDataSetChanged()
            }
        }
    }

    // Adapter class
    class CropAdapter(private val items: List<CropPrice>) :
        RecyclerView.Adapter<CropAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val cropText: TextView = view.findViewById(R.id.tvCropName)
            val usdText: TextView = view.findViewById(R.id.tvUsdPrice)
            val phpText: TextView = view.findViewById(R.id.tvPhpPrice)
            val exchText: TextView = view.findViewById(R.id.tvExchange)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_crop_price, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.cropText.text = "Commodity: ${item.cropName}"
            holder.usdText.text = "USD Price: $${"%.2f".format(item.priceUSD)}"
            holder.phpText.text = "PHP Price: ₱${"%.2f".format(item.pricePHP)}"
            holder.exchText.text = "Exchange: ${item.exchange}"
        }

        override fun getItemCount(): Int = items.size
    }
}
